<?php
$string['pluginname'] = '[Cocoon] Action Panels';
$string['cocoon_action_panels'] = '[Cocoon] Action Panels';
$string['cocoon_action_panels:addinstance'] = 'Add a new Action Panels block';
$string['cocoon_action_panels:myaddinstance'] = 'Add a new Action Panels block to the My Moodle page';
$string['config_title'] = 'Title';
$string['config_panel_1'] = 'Panel left';
$string['config_panel_1_title'] = 'Panel title';
$string['config_panel_1_text'] = 'Panel body';
$string['config_panel_1_button_text'] = 'Button text';
$string['config_panel_1_button_url'] = 'Button link';
$string['config_panel_2'] = 'Panel right';
$string['config_panel_2_title'] = 'Panel title';
$string['config_panel_2_text'] = 'Panel body';
$string['config_panel_2_button_text'] = 'Button text';
$string['config_panel_2_button_url'] = 'Button link';
